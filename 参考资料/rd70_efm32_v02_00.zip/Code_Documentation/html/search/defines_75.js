var searchData=
[
  ['using_5fevent_5ftiming_5fmodes_5fread_5faverage',['USING_EVENT_TIMING_MODES_READ_AVERAGE',['../_m_a_x_r_e_f_d_e_s70_8c.html#a3fe86a8744a349ceb2caa0d93e4f675b',1,'MAXREFDES70.c']]]
];
