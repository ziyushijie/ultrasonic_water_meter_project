var searchData=
[
  ['init',['init',['../_m_a_x_r_e_f_d_e_s70_8c.html#a2858154e2009b0e6e616f313177762bc',1,'MAXREFDES70.c']]]
];
