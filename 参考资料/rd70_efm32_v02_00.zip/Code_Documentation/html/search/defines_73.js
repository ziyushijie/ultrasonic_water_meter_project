var searchData=
[
  ['seconds',['SECONDS',['../_m_a_x_r_e_f_d_e_s70_8c.html#a48fcf4f2eeef6769d588168d4ac2ab0e',1,'MAXREFDES70.c']]],
  ['seconds_5fper_5fhr',['SECONDS_PER_HR',['../_m_a_x_r_e_f_d_e_s70_8c.html#a24cbb1e532cefe532f839cebfdc8a206',1,'MAXREFDES70.c']]],
  ['spi_5fbaudrate',['SPI_BAUDRATE',['../_m_a_x_r_e_f_d_e_s70_8c.html#a4dad4b502d445b46f33cdd159e04051a',1,'MAXREFDES70.c']]],
  ['spi_5fperclk_5ffrequency',['SPI_PERCLK_FREQUENCY',['../_m_a_x_r_e_f_d_e_s70_8c.html#ad74358bcd9935652ef1684242002dfa4',1,'MAXREFDES70.c']]]
];
