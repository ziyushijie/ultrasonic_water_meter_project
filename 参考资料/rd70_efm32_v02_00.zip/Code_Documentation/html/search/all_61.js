var searchData=
[
  ['avgdown_5freg',['AVGDOWN_REG',['../_m_a_x_r_e_f_d_e_s70_8c.html#ac1b3fdc524d73174f63960152c9b0217',1,'MAXREFDES70.c']]],
  ['avgup_5freg',['AVGUP_REG',['../_m_a_x_r_e_f_d_e_s70_8c.html#a5ceb049cd8d77679a5d2c645908f2cee',1,'MAXREFDES70.c']]]
];
