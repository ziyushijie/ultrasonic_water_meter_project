var searchData=
[
  ['read_5fflash',['READ_FLASH',['../_m_a_x_r_e_f_d_e_s70_8c.html#a881ad9a67ebabef3548ec7e52f63241c',1,'MAXREFDES70.c']]],
  ['reference_5ftemp_5fport',['REFERENCE_TEMP_PORT',['../_m_a_x_r_e_f_d_e_s70_8c.html#a1e7fe4c0ba81bb46a6346e73e4b8b515',1,'MAXREFDES70.c']]],
  ['reg',['reg',['../_m_a_x_r_e_f_d_e_s70_8c.html#a11760f5020019f4aa8cb02e694f7cc44',1,'MAXREFDES70.c']]],
  ['register_5fvalue',['Register_Value',['../struct_temperature___results_struct.html#a2eecd9eb1e64c90d60425744266a123e',1,'Temperature_ResultsStruct']]],
  ['reset',['RESET',['../_m_a_x_r_e_f_d_e_s70_8c.html#ab702106cf3b3e96750b6845ded4e0299',1,'MAXREFDES70.c']]],
  ['rtd_5frref_5fvalue',['RTD_RREF_VALUE',['../_m_a_x_r_e_f_d_e_s70_8c.html#adcca0ce2d549f92e34084e2593aa35db',1,'MAXREFDES70.c']]]
];
