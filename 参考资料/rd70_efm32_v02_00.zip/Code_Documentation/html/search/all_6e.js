var searchData=
[
  ['no_5frx',['NO_RX',['../_m_a_x_r_e_f_d_e_s70_8c.html#a28972ee0daa5bdaf8d504d06abc9a1f8',1,'MAXREFDES70.c']]],
  ['no_5ftx',['NO_TX',['../_m_a_x_r_e_f_d_e_s70_8c.html#a2ca13cc687b31de4a8cb9071cf5208ef',1,'MAXREFDES70.c']]],
  ['number_5ftemperatue_5fports_5fused',['NUMBER_TEMPERATUE_PORTS_USED',['../_m_a_x_r_e_f_d_e_s70_8c.html#ab8c77e8cc6309ffb58e1149b99ea6344',1,'MAXREFDES70.c']]]
];
