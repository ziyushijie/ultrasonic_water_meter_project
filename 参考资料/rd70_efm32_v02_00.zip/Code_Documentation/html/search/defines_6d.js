var searchData=
[
  ['max35101_5fcs_5fhigh',['MAX35101_CS_High',['../_m_a_x_r_e_f_d_e_s70_8c.html#a3438afdab560f313abcce9650d4e6709',1,'MAXREFDES70.c']]],
  ['max35101_5fcs_5flow',['MAX35101_CS_Low',['../_m_a_x_r_e_f_d_e_s70_8c.html#a5006b3dfd12dbb34108921762dd99148',1,'MAXREFDES70.c']]],
  ['max_5fdisplay_5frepeat',['MAX_DISPLAY_REPEAT',['../_m_a_x_r_e_f_d_e_s70_8c.html#a21c5a03be78fe4b4e48f1eb6f943b7d7',1,'MAXREFDES70.c']]],
  ['mins_5fhrs',['MINS_HRS',['../_m_a_x_r_e_f_d_e_s70_8c.html#a1ac11ce0832fc1e823899cca585d5869',1,'MAXREFDES70.c']]],
  ['month_5fyear',['MONTH_YEAR',['../_m_a_x_r_e_f_d_e_s70_8c.html#a3823c1f48f1b65776d6833f47a6e1299',1,'MAXREFDES70.c']]]
];
