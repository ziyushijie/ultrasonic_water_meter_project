var struct_temperature_results_all_ports_struct =
[
    [ "TempResultsAllPorts", "struct_temperature_results_all_ports_struct.html#ab4f53a16c1ccb11137547b300162a1d1", null ]
];