var struct_flow___results_struct =
[
    [ "FlowVelocity_mPerS", "struct_flow___results_struct.html#ab2986dd07188109f9f363909016ffe7e", null ],
    [ "TOF_DIFF_DeltaT_S", "struct_flow___results_struct.html#a24473df71a53e74468d00e47a6865735", null ],
    [ "TOF_DiffData", "struct_flow___results_struct.html#ade669ef9a0f8d6dd580c31da4068dc61", null ],
    [ "VolumetricFlow_m3PerS", "struct_flow___results_struct.html#a5fd517ce5f69f4373c496d5a31473f67", null ],
    [ "VolumetricFlowCorrected_m3PerS", "struct_flow___results_struct.html#a0f76c2c3d07227b91940bfc6a4b1ba02", null ],
    [ "VolumetricFlowGainFactor", "struct_flow___results_struct.html#a4a57a75cb51564c6af0a1d49122b1963", null ]
];