var struct_point_of_time_sample_data_struct =
[
    [ "POT_EnergyFactors", "struct_point_of_time_sample_data_struct.html#aaab5b43a08db9e2b1b18f4c5a3101069", null ],
    [ "POT_FlowFactors", "struct_point_of_time_sample_data_struct.html#a10a421d05e0714e5f19f400e20d2168d", null ],
    [ "POT_TemperatureData", "struct_point_of_time_sample_data_struct.html#aff5c1401da4a16b1d178a9239525573b", null ],
    [ "POT_TimeData", "struct_point_of_time_sample_data_struct.html#afb21abf609170df3cafcd9eec01c23bf", null ]
];