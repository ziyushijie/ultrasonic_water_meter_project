var searchData=
[
  ['spi_5fread_5fword',['SPI_Read_Word',['../_m_a_x_r_e_f_d_e_s70_8c.html#a98147c62f82221ea759652accb7a89e9',1,'MAXREFDES70.c']]],
  ['spi_5fsend_5fbyte',['SPI_Send_Byte',['../_m_a_x_r_e_f_d_e_s70_8c.html#a0b7b1490d0d2b7ad905019aaa1753e97',1,'MAXREFDES70.c']]],
  ['systick_5fhandler',['SysTick_Handler',['../_m_a_x_r_e_f_d_e_s70_8c.html#ab5e09814056d617c521549e542639b7e',1,'MAXREFDES70.c']]]
];
