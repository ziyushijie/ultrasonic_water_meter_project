var searchData=
[
  ['delaycount',['delayCount',['../_m_a_x_r_e_f_d_e_s70_8c.html#a033d15e83c43469248d0b6b80c56d032',1,'MAXREFDES70.c']]],
  ['displaymode',['DisplayMode',['../_m_a_x_r_e_f_d_e_s70_8c.html#ae939b01146c8d67526fecaeb2a6c0fa4',1,'MAXREFDES70.c']]],
  ['displaypoweroff',['displayPowerOff',['../_m_a_x_r_e_f_d_e_s70_8c.html#a29a0e0de1ec191eb86e12a44077ba797',1,'MAXREFDES70.c']]],
  ['displayrepeat',['displayRepeat',['../_m_a_x_r_e_f_d_e_s70_8c.html#a23b9798a0eb53d48b5108a6582d3d87f',1,'MAXREFDES70.c']]]
];
