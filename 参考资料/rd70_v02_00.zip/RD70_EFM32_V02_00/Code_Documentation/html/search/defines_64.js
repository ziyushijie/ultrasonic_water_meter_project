var searchData=
[
  ['day_5fdate',['DAY_DATE',['../_m_a_x_r_e_f_d_e_s70_8c.html#a774c8be9dae808a428b394b85ce661c7',1,'MAXREFDES70.c']]]
];
