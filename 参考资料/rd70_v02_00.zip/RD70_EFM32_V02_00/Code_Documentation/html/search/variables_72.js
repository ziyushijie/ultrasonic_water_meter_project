var searchData=
[
  ['reg',['reg',['../_m_a_x_r_e_f_d_e_s70_8c.html#a11760f5020019f4aa8cb02e694f7cc44',1,'MAXREFDES70.c']]],
  ['register_5fvalue',['Register_Value',['../struct_temperature___results_struct.html#a2eecd9eb1e64c90d60425744266a123e',1,'Temperature_ResultsStruct']]]
];
