var searchData=
[
  ['batterylevel_2ec',['batteryLevel.c',['../battery_level_8c.html',1,'']]],
  ['batterylevel_2eh',['batteryLevel.h',['../battery_level_8h.html',1,'']]]
];
