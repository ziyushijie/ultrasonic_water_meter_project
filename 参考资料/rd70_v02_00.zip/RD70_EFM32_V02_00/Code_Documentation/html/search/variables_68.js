var searchData=
[
  ['hit1data',['Hit1Data',['../struct_hit___results_struct.html#ae214150b13bd80b5f4e2e14c5b52d14c',1,'Hit_ResultsStruct']]],
  ['hit2data',['Hit2Data',['../struct_hit___results_struct.html#a67c97baf4bb3dc7622ac09211ef838a8',1,'Hit_ResultsStruct']]],
  ['hit3data',['Hit3Data',['../struct_hit___results_struct.html#af36637ada1984b1af688589b5dd068e1',1,'Hit_ResultsStruct']]],
  ['hit4data',['Hit4Data',['../struct_hit___results_struct.html#a27921afe72a107fecab0440f75f96e3f',1,'Hit_ResultsStruct']]],
  ['hit5data',['Hit5Data',['../struct_hit___results_struct.html#a9187c6de6372bdd64d1bd68037210f36',1,'Hit_ResultsStruct']]],
  ['hit6data',['Hit6Data',['../struct_hit___results_struct.html#a9bed8739b1ca065713978e3298543418',1,'Hit_ResultsStruct']]],
  ['hitaveragedata',['HitAverageData',['../struct_hit___results_struct.html#aaf355a77d9261e732c410f60503a2346',1,'Hit_ResultsStruct']]]
];
