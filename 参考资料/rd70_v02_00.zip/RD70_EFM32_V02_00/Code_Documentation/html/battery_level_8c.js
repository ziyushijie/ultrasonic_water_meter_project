var battery_level_8c =
[
    [ "batteryLevel", "battery_level_8c.html#adacb8f18717ab95d80f1da42da0ee303", null ],
    [ "WaitForComparatorUpdate", "battery_level_8c.html#aeaa94d27525e832ce73892b6cc2b46ef", null ]
];