var battery_level_8h =
[
    [ "BatteryLevel", "battery_level_8h.html#a0a8500b8cc4a567c31410185022fd378", null ]
];