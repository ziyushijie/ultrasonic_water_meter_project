var struct_hit___results_struct =
[
    [ "Hit1Data", "struct_hit___results_struct.html#ae214150b13bd80b5f4e2e14c5b52d14c", null ],
    [ "Hit2Data", "struct_hit___results_struct.html#a67c97baf4bb3dc7622ac09211ef838a8", null ],
    [ "Hit3Data", "struct_hit___results_struct.html#af36637ada1984b1af688589b5dd068e1", null ],
    [ "Hit4Data", "struct_hit___results_struct.html#a27921afe72a107fecab0440f75f96e3f", null ],
    [ "Hit5Data", "struct_hit___results_struct.html#a9187c6de6372bdd64d1bd68037210f36", null ],
    [ "Hit6Data", "struct_hit___results_struct.html#a9bed8739b1ca065713978e3298543418", null ],
    [ "HitAverageData", "struct_hit___results_struct.html#aaf355a77d9261e732c410f60503a2346", null ],
    [ "t1Ratiot2", "struct_hit___results_struct.html#a3798d16e24047653fbeec3f744b35661", null ],
    [ "t2RatiotIdeal", "struct_hit___results_struct.html#afebb379dc063c8d7ddd32f843c926534", null ]
];