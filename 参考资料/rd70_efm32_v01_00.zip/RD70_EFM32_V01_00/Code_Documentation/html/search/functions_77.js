var searchData=
[
  ['waitforcomparatorupdate',['WaitForComparatorUpdate',['../battery_level_8c.html#aeaa94d27525e832ce73892b6cc2b46ef',1,'batteryLevel.c']]]
];
