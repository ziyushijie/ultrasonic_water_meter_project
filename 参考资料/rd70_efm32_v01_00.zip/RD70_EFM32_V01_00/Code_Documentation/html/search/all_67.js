var searchData=
[
  ['gpio_5feven_5firqhandler',['GPIO_EVEN_IRQHandler',['../_m_a_x_r_e_f_d_e_s70_8c.html#a87d72653156b83829786f1f856ecbad1',1,'MAXREFDES70.c']]],
  ['gpio_5fodd_5firqhandler',['GPIO_ODD_IRQHandler',['../_m_a_x_r_e_f_d_e_s70_8c.html#a8fff5a798ff4721659dc7bdbb3149c8b',1,'MAXREFDES70.c']]]
];
