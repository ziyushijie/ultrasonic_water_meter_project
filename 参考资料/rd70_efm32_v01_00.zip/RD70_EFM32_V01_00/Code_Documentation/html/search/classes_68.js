var searchData=
[
  ['hit_5fresultsstruct',['Hit_ResultsStruct',['../struct_hit___results_struct.html',1,'']]]
];
