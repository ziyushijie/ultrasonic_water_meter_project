var dogm163_8h =
[
    [ "DOGM163_ClearChars", "dogm163_8h.html#a92db4e099c54f69ba2b4dffe677eae26", null ],
    [ "DOGM163_Init", "dogm163_8h.html#a5b7f0315f061f471958ceb405721963e", null ],
    [ "DOGM163_PowerOff", "dogm163_8h.html#a92d62c2e02900baf246fe9fe8a010b19", null ],
    [ "DOGM163_PrintChars", "dogm163_8h.html#a399cfe3743ee2711fe588eb1ccbcced8", null ],
    [ "DOGM163_PrintInteger", "dogm163_8h.html#a3593484129fea4f705df7e881040d2b6", null ],
    [ "DOGM163_PrintWelcomeMsg", "dogm163_8h.html#a5ee4d5deafa33aeefc4e807c0b98e3b4", null ],
    [ "DOGM163_SpiTransmit", "dogm163_8h.html#a58278cf0604caeb0ec0d6447e11b42ef", null ],
    [ "DOGM163_WriteCmdByte", "dogm163_8h.html#a3447b580188f8b25628b0bf3c1755d25", null ],
    [ "DOGM163_WriteDataByte", "dogm163_8h.html#a501a8e5f7688a41230024e6a0e92280f", null ]
];