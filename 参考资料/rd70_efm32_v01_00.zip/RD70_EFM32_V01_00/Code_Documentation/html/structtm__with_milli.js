var structtm__with_milli =
[
    [ "milliSeconds", "structtm__with_milli.html#abb80ca71c68a520b01254c433579b5d3", null ],
    [ "Time", "structtm__with_milli.html#ac19c63be5e4998e3d875094011109187", null ]
];