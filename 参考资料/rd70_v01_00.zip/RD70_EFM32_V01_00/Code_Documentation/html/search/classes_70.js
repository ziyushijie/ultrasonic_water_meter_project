var searchData=
[
  ['pointoftimesampledatastruct',['PointOfTimeSampleDataStruct',['../struct_point_of_time_sample_data_struct.html',1,'']]]
];
