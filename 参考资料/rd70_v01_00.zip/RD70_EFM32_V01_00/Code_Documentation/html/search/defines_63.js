var searchData=
[
  ['calibrates',['CALIBRATES',['../_m_a_x_r_e_f_d_e_s70_8c.html#ae3cad406bcac79e5542608b25b83fc0c',1,'MAXREFDES70.c']]],
  ['cold_5ftemp_5fport',['COLD_TEMP_PORT',['../_m_a_x_r_e_f_d_e_s70_8c.html#abb3808f73e05bedae88bcc8283b58732',1,'MAXREFDES70.c']]]
];
