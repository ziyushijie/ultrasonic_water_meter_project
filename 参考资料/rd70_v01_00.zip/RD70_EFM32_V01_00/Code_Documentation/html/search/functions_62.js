var searchData=
[
  ['batterylevel',['batteryLevel',['../battery_level_8c.html#adacb8f18717ab95d80f1da42da0ee303',1,'batteryLevel(void):&#160;batteryLevel.c'],['../battery_level_8h.html#a0a8500b8cc4a567c31410185022fd378',1,'BatteryLevel(void):&#160;batteryLevel.h']]]
];
