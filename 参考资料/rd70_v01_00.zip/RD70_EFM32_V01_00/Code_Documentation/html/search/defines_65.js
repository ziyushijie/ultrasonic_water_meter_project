var searchData=
[
  ['evtmg1',['EVTMG1',['../_m_a_x_r_e_f_d_e_s70_8c.html#a512562b52ab50763127024d134857d54',1,'MAXREFDES70.c']]],
  ['evtmg2',['EVTMG2',['../_m_a_x_r_e_f_d_e_s70_8c.html#a7c0d6cde8e069dd077b0a53750aa76d2',1,'MAXREFDES70.c']]],
  ['evtmg3',['EVTMG3',['../_m_a_x_r_e_f_d_e_s70_8c.html#a8ff1cb67a685e01ee34d30aabfe685d7',1,'MAXREFDES70.c']]]
];
