var struct_temperature___results_struct =
[
    [ "Register_Value", "struct_temperature___results_struct.html#a2eecd9eb1e64c90d60425744266a123e", null ],
    [ "TemperatureDegreeC", "struct_temperature___results_struct.html#a3a2dbffe2c1caba9f7c7292eb626cf5f", null ]
];