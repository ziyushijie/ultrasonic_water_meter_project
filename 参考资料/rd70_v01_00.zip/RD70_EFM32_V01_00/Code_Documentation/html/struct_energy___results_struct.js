var struct_energy___results_struct =
[
    [ "EnthalpyAtCold_JperKg", "struct_energy___results_struct.html#a7223e9916a7ddc2f5610b7fcc7be7613", null ],
    [ "EnthalpyAtHot_JperKg", "struct_energy___results_struct.html#a29f022384cdd8910a606e56dcb309988", null ],
    [ "EnthalpyDelta_JperKg", "struct_energy___results_struct.html#aff367965f261a4057e2c304c519b8387", null ],
    [ "MassFlow_kgPerh", "struct_energy___results_struct.html#aaf82d81751a3ea93488dca095289162a", null ]
];